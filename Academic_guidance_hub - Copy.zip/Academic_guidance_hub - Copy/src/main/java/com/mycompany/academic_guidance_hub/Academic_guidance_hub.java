/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.academic_guidance_hub;

/**
 *
 * @author User
 */
public class Academic_guidance_hub {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
