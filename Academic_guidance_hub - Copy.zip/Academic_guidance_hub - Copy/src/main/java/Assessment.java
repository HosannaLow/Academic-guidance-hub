/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Assessment {
    private String name;
    private String tpNo;
    private String IntakeCode;
    private String subject;
    private String typeOfAssessment;
    private String selectedDate;
    private String fileName;
    private String attachment;
    private String status;
    private double grade;

public Assessment(String name,String tpNo,String IntakeCode,String subject,String typeOfAssessment,
        String selectedDate,String fileName,String attachment,String status,double grade){
    this.name = name;
    this.tpNo = tpNo;
    this.IntakeCode = IntakeCode;
    this.subject = subject;
    this.typeOfAssessment= typeOfAssessment;
    this.selectedDate = selectedDate;
    this.fileName = fileName;
    this.attachment=attachment;
    this.status = status;
    this.grade = grade;
}

public String getName(){
    return name;
}

public void setName(String name){
    this.name = name;
}

public String getTPno(){
    return tpNo;
}

public void setTPno(String tpNo){
    this.tpNo= tpNo;
}
public String getIntakeCode(){
    return IntakeCode;
}
public void setCusIC(String IntakeCode){
    this.IntakeCode = IntakeCode;
}
public String getSubject(){
    return subject;
}
public void setSubject(String subject){
    this.subject = subject;
}
public String getTypeOfAssessment(){
    return typeOfAssessment;
}
public void setTypeOfAssessment(String typeOfAssessment){
    this.typeOfAssessment = typeOfAssessment;
}
public String getSelectedDate(){
    return selectedDate;
}
public void setSelectedDate(String selectedDate){
    this.selectedDate= selectedDate;
}
public String getFileName(){
    return fileName;
}
public void setFileName(String fileName){
    this.fileName = fileName;
}
public String getAttachment(){
    return attachment;
}
public void setAttachment(String attachment){
    this.attachment=attachment;
}
public String getStatus(){
    return status;
}

public void setStatus(String status){
    this.status = status;
} 
public double getGrade(){
    return grade;
}
public void setGrade(double grade){
    this.grade = grade;
}
@Override
public String toString(){
    return name +","+ tpNo+","+IntakeCode +","+subject +","+typeOfAssessment+","+selectedDate+","+fileName+","+attachment+","+status+","+grade;
}

    void add(Assessment assessment) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

